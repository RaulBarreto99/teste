/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adocollection;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author rbarreto
 */
public class Sort1 {
    public static void main(String[] args) {        
        List<String> list = Arrays.asList("Hearts","Diamonds","Clubs","Spades");
        System.out.printf("Unsorted array elements: %s%n",list);
        
        Collections.sort(list);
        System.out.printf("Sorted array elements: %s%n",list);
        
    }
    
    
}
